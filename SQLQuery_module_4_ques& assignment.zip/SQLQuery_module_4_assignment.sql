-------------------------------Module-4 Assignment--------------------------------------

----1.	Use the inbuilt functions and find the minimum, maximum and average amount from the orders table

select * from orders

select min(amount) as minumu_amount, 
max(amount) as maximum_amount ,
avg(amount) as average_amount 
from orders

---2.Create a user-defined function, which will multiply the given number with 10

create function multiply_10(@num int)
returns int
as begin
return(@num*10)
end

select dbo.multiply_10(amount) 
from orders as result

----3.Use the case statement to check if 100 is less than 200, greater than 200 or equal to 2oo and print the corresponding value
select
case
when 100<200 then '100 is less than 200'
when 100>200 then '100 is greater than 200'
else '100 is squal to 200'
end 



