---------------------------Module-2 Assignment----------------------------

---1. Create a customer table which comprises of these columns � �customer_id�, �first_name�, 
--�last_name�, �email�, �address�, �city�,�state�,�zip�

create table Customer
(customer_id int , first_name Varchar (20) , last_name varchar(20) , email varchar (30) ,
address varchar (50) , city varchar(20) , state varchar (20), zip int)



---2. Insert 5 new records into the table

insert into customer values(10,'Sanjay','Satyapal','ss@gmail.com','tower8','Pune','Maharashtra',410072)
insert into customer values(20,'manjula','malapati','manjula@gmail.com','tower9','chennai','tamilnadu',410873)
insert into customer values(30,'george','yuss','gg@gmail.com','kingstown','sanjose','california',100987)
insert into customer values(40,'ravindra','yadav','rr@gmail.com','tower7','bangalore','karnataka',570072)
insert into customer values(50,'Sara','Soni','soo@gmail.com','tower5','merut','uttarpradesh',419972)


---3 .Select only the �first_name� & �last_name� columns from the customer table

select first_name , last_name from customer

---4. Select those records where �first_name� starts with �G� and city is �San Jose�

select First_name as name
from customer
where first_name like 'g%' and city = 'SanJose'