--------------------------------------------Module-3 Assignment----------------------------------

---1.	Create an �Orders� table which comprises of these columns � �order_id�, �order_date�, �amount�, �customer_id�	

create table Orders
(orders_id int , order_date date , amount int , customer_id int)

insert into orders values
(101,'2022/08/13',1500,10),
(102,'2022/07/08',6000,20),
(103,'2023/02/13',5400,80),
(104,'2023/06/23',1800,40),
(105,'2022/07/05',2300,70);

----2.	Make an inner join on �Customer� & �Order� tables on the �customer_id� column

Select *
from customer c
inner join orders o
on c.customer_id = o.customer_id

---3.	Make left and right joins on �Customer� & �Order� tables on the �customer_id� column

select *
from customer as c
left join orders as o
on c.customer_id =o.customer_id

select *
from customer as c
right join orders as o
on c.customer_id=o.customer_id


---4.	Update the �Orders� table, set the amount to be 100 where �customer_id� is 3

update orders
set amount=100 
where customer_id=3
